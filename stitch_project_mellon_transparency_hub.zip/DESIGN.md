---
name: Third Age Ledger
colors:
  surface: '#fff8f0'
  surface-dim: '#e9d9b1'
  surface-bright: '#fff8f0'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff3d7'
  surface-container: '#fdedc4'
  surface-container-high: '#f7e7bf'
  surface-container-highest: '#f1e1b9'
  on-surface: '#221b03'
  on-surface-variant: '#504440'
  inverse-surface: '#383014'
  inverse-on-surface: '#fff0ca'
  outline: '#827470'
  outline-variant: '#d3c3be'
  surface-tint: '#74584e'
  primary: '#090100'
  on-primary: '#ffffff'
  primary-container: '#2c1810'
  on-primary-container: '#9e7e73'
  inverse-primary: '#e3bfb2'
  secondary: '#6d5b48'
  on-secondary: '#ffffff'
  secondary-container: '#f7dec6'
  on-secondary-container: '#73614e'
  tertiary: '#060200'
  on-tertiary: '#ffffff'
  tertiary-container: '#261b0f'
  on-tertiary-container: '#938271'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#e3bfb2'
  on-primary-fixed: '#2a170f'
  on-primary-fixed-variant: '#5a4137'
  secondary-fixed: '#f7dec6'
  secondary-fixed-dim: '#dac2ab'
  on-secondary-fixed: '#26190a'
  on-secondary-fixed-variant: '#544432'
  tertiary-fixed: '#f4dfcb'
  tertiary-fixed-dim: '#d7c3b0'
  on-tertiary-fixed: '#241a0d'
  on-tertiary-fixed-variant: '#524436'
  background: '#fff8f0'
  on-background: '#221b03'
  surface-variant: '#f1e1b9'
typography:
  headline-lg:
    fontFamily: Bricolage Grotesque
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Bricolage Grotesque
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Source Serif 4
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  number-display:
    fontFamily: Literata
    fontSize: 22px
    fontWeight: '700'
    lineHeight: '1.2'
  caption:
    fontFamily: Literata
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.4'
spacing:
  unit: 4px
  gutter: 24px
  margin: 32px
  ledger-line: 32px
---

## Brand & Style
The design system adopts a **Historical Minimalist** aesthetic, specifically emulating a Third Age fiscal receipt. The interface is not a digital application in the modern sense, but a digital restoration of ink-on-parchment bookkeeping. 

The personality is communal and official yet rustic—evoking the atmosphere of a bustling inn or a drafty stone office in Bree. The UI avoids all modern affordances like glows, gradients, or high-tech glass. Instead, it relies on the tactile quality of physical media: the weight of ink, the grain of paper, and the deliberate imperfection of hand-drawn marks. The goal is to make the user feel like they are reviewing a town's physical records by candlelight.

## Colors
The palette is restricted to organic pigments found in the Shire and Bree-land.
- **Surface (#f4e4bc):** A warm, weathered parchment. It serves as the primary canvas for all interactions.
- **Primary Ink (#2c1810):** A deep, iron-gall brown used for the majority of text and structural lines. It has a slight warmth to distinguish it from sterile black.
- **Secondary Ink (#5e4d3b):** A diluted wash for secondary labels, less urgent annotations, and subtle woodblock patterns.
- **Accents:** No vibrant colors are permitted. Functionality is communicated through line weight and placement rather than hue shifts.

## Typography
Typography is the primary vehicle for the historical narrative. We utilize a contrast between characterful, "hand-carved" headings and disciplined, scholarly body text.

- **Headings:** Bricolage Grotesque is used to simulate a rustic, hand-drawn script. Its irregular curves evoke the feel of a quill-written ledger title.
- **Body & Lists:** Source Serif 4 provides high legibility for tax records and long lists. It feels professional and established.
- **Data & Numbers:** Literata is used for financial figures and labels, offering a sturdy, bookish quality that ensures clarity in tallies.

Avoid all-caps for body text. Use italics sparingly for "scribbled" marginalia or clarifications.

## Layout & Spacing
The layout follows a **Vertical Ledger Model**. Content is organized as a continuous scroll or a single, fixed-width receipt strip. 

- **Grid:** A centered 8-column layout for desktop, collapsing to a single column for mobile. 
- **Rhythm:** Spacing should feel intentional but slightly uneven, as if penned by hand. Use a 4px baseline, but do not adhere to it with digital perfection.
- **Separators:** Use "squiggly" hand-drawn horizontal lines (SVG paths) instead of standard `<hr>` tags. These lines should vary slightly in thickness to mimic quill pressure.
- **Margins:** Large, generous margins (minimum 32px) simulate the physical edges of a piece of parchment.

## Elevation & Depth
In this design system, depth is achieved through **Tonal Layering** and physical metaphors rather than shadows.

- **No Shadows:** Physical shadows do not exist on a flat piece of paper. To show "elevation," use a slightly darker parchment shade or a subtle "ink wash" background.
- **Deckled Edges:** The primary container should have a non-straight, visual "torn" edge effect applied via mask-image.
- **Z-Index:** Content is conceptually flat. If an element must appear "on top" (like a modal), it should appear as a smaller slip of paper pinned or laid over the main document, distinguished by a thin, hand-drawn border rather than a drop shadow.

## Shapes
The shape language is strictly **Sharp and Organic**. 

- **Corners:** Buttons and containers use 0px radius. The "roundedness" comes from the visual texture of the edges (the deckled effect), not the geometry of the box itself.
- **Selection:** Instead of rounded corners, active states are indicated by a hand-drawn "circle" or "underline" effect that looks like an ink mark.

## Components
Components must look like they were produced by a woodblock print or a steady hand.

- **Buttons:** Styled as "Stamp" areas. They consist of a solid ink border (2px) with text centered inside. On hover, the background fills with a light ink wash (#8c7b6a at 10% opacity).
- **Input Fields:** No boxes. Use a single, dark ink underline. The text should sit slightly above the line, mimicking a signature line.
- **Checkboxes:** Represented by an "X" mark inside a hand-drawn square. 
- **Lists (The Tax Roll):** Items are separated by subtle dotted lines. Numbers are right-aligned to ensure the "shillings and pence" columns are easy to scan.
- **Cards (The Ledger Slip):** Use these for specific entries. They are essentially smaller blocks of text bounded by simple woodblock corners (e.g., L-shaped ink marks).
- **Stamps:** Success messages should be represented as a visual "Paid" or "Approved" stamp in a slightly faded secondary ink color, rotated 5-10 degrees for authenticity.